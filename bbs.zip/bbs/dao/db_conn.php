<?php
    $conn = mysql_connect("localhost", "root", "toor");
    mysql_select_db("bbs", $conn);

    if(!$conn){
        echo '[failed] : '.mysql_error().''; 
        die('MySQL failed');
    } else {
        // echo '[success]';
    }
?>
