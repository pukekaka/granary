<?php
session_start();
include "../dao/db_conn.php";

$name = $_SESSION[userid];
$no = $_GET[no];

$query_select = "SELECT name FROM board WHERE no=$no";
$result = mysql_query($query_select, $conn);
$row=mysql_fetch_array($result);

if ($name == $row[name]){
    $query_delete = "DELETE FROM board WHERE no=$no";
    print_r($query_delete);
    // $result=mysql_query($query_update, $conn);

}else{
    echo "<script>alert('Delete Error');</script>";
    exit();
}

mysql_close($conn);
// echo ("<meta http-equiv='Refresh' content='0; URL=../main.php'>");
?>