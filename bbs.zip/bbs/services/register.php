<?php
include "../dao/db_conn.php";

if(!isset($_POST[userid]) or !isset($_POST[userpw]) or !isset($_POST[username]) or $_POST[userid]==='' or $_POST[userpw]==='' or $_POST[username]===''){
    echo "<script>alert('Input id, name, passwd')</script>";
    // echo "<script>history.bak();</script>";
}


$userid = $_POST[userid];
$userpw = $_POST[userpw];
$hash_pw = hash("sha256", $pw);
$username = $_POST[username];

$query_select = "SELECT * FROM users WHERE userid='$userid'";
$ret_select = mysql_query ( $query_select );
$cnt = mysql_num_rows($ret_select);

if($cnt){
    echo "<script>alert('Already Exist');</script>";
    // echo "<script>history.bak();</script>";
    exit();
}

$query_insert = "INSERT INTO users(userid, userpw, name) VALUES('$userid', '$hash_pw', '$username')";
$ret_insert = mysql_query( $query_insert);

mysql_close($conn);

if($ret_insert){
    echo "<script> alert('Register Success');</script>";
    echo "<meta http-equiv='refresh' content=\"0;url=../main.php\">";
    exit(0);
}else{
    echo "<script> alert('Database Error');</script>";
}

?>