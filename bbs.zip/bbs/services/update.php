<?php
session_start();
include "../dao/db_conn.php";

$name = $_SESSION[userid];
$no = $_GET[no];
$title = $_POST[title];
$content = $_POST[content];

$query_select = "SELECT name FROM board WHERE no=$no";
$result = mysql_query($query_select, $conn);
$row=mysql_fetch_array($result);

if ($name == $row[name]){
    $query_update = "UPDATE board SET title='$title', content='$content' WHERE no=$no";
    $result=mysql_query($query_update, $conn);

}else{
    echo "<script>alert('Update Error');</script>";
    exit();
}

mysql_close($conn);
echo ("<meta http-equiv='Refresh' content='1; URL=read.php?no=$no'>");
?>