<?php
session_start();
include "../dao/db_conn.php";

if(!isset($_POST[title]) or $_POST[title]===''){
    echo "<script>alert('Empty Title or Content')</script>";
    // echo "<script>history.bak();</script>";
}

$title = $_POST[title];
$content = $_POST[content];
$name = $_SESSION[userid];

$query_insert = "INSERT INTO board(name, title, content, wdate, view_count) VALUES('$name', '$title', '$content', now(), 0)";

$ret_insert = mysql_query ( $query_insert );

mysql_close($conn);

if($ret_insert){
    echo "<script>alert('Save Complete');</script>";
    echo "<meta http-equiv='refresh' content=\"0;url=../main.php\">";
    exit();
}else{
    echo "<script>alert('Save Error');</script>";
}

?>