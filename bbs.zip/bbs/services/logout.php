<?php
    session_start();
    setcookie(session_name(), '', time()-999999999999, '/');
    session_destroy();
?>
<meta http-equiv='refresh' content='0;url=../main.php'>