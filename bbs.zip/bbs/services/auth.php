<?php
session_start();
include "../dao/db_conn.php";

if(!isset($_POST[userid]) or !isset($_POST[userpw]) or $_POST[userid]==='' or $_POST[pw]===''){
    echo "<script>alert('Input id, name, passwd')</script>";
    // echo "<script>history.bak();</script>";
}


$userid = $_POST[userid];
$userpw = $_POST[userpw];
$hash_pw = hash("sha256", $pw);

$query_select = "SELECT * FROM users WHERE userid='$userid' and userpw='$hash_pw'";
$ret_select = mysql_query ( $query_select );
$row = mysql_fetch_array($ret_select, MYSQL_ASSOC);

mysql_close($conn);

if(strcmp($id ,$row[userid])){

    $_SESSION[userid] = $row[userid];
    $_SESSION[username] = $row[name];
    $_SESSION[is_login] = 1;
    echo "<meta http-equiv='refresh' content=\"0;url=../main.php\">";
}else{
    echo "<script>alert('auth failed!!');</script>";
    echo "<meta http-equiv='refresh' content=\"0;url=../main.php\">";
    exit(0);
}

?>