<?php
session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/bootstrap/site/favicon.ico">

    <title>Board</title>

    <!-- Bootstrap core CSS -->
    <link href="/bootstrap/dist/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="/bootstrap/site/docs/4.1/examples/jumbotron/jumbotron.css" rel="stylesheet">
  </head>

  <body>

    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="#">Board</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
        </ul>
<?php
  if(!isset( $_SESSION[is_login] ) or $_SESSION[is_login]!==1){
?>
       <meta http-equiv='refresh' content='0;url=../main.php'>
<?php
  }else{
?>
        <form class="form-inline my-1 my-lg-0" method="POST" action="../services/logout.php">
        <button class="btn btn-outline-success my-1 mr-sm-5" type="submit">Sign out</button>
<?php
  }
?>
        </form>
      </div>
    </nav>

    <main role="main">

    <div class="container">
      <br>
      <br>
      <br>
        <form method="POST" action="../services/save.php">
          <div class="form-group">
            <label>Title</label>
            <input type="text" name="title" class='form-control' placeholder="Title" required>
          </div>
          <div class="form-group">
            <label>Content</label>
            <textarea class="form-control" name="content" id="Content" rows="15"></textarea>
          </div>
          <button class="btn btn-outline-success my-1 mr-sm-2" type="submit">Save</button>
          <button class="btn btn-outline-danger my-1 mr-sm-2" type="button" onclick="history.back(-1)">Cancel</button>     
        </form>     
      </div> <!-- /container -->
    </main>

    <footer class="container">
      <p>&copy; 2018</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="/bootstrap/site/docs/4.1/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="/bootstrap/site/docs/4.1/assets/js/vendor/popper.min.js"></script>
    <script src="/bootstrap/dist/js/bootstrap.min.js"></script>
  </body>
</html>
