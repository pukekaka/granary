<?php
session_start()
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/bootstrap/site/favicon.ico">

    <title>Board</title>

    <!-- Bootstrap core CSS -->
    <link href="/bootstrap/dist/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="/bootstrap/site/docs/4.1/examples/jumbotron/jumbotron.css" rel="stylesheet">
  </head>

  <body>

    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="#">Board</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
        </ul>
<?php
  if(!isset( $_SESSION[is_login] ) or $_SESSION[is_login]!==1){
?>
        <form class="form-inline my-2 my-lg-0" method="POST" action="services/auth.php">
          <input class="form-control mr-sm-2" type="text" name="userid" placeholder="User" aria-label="User">
          <input class="form-control mr-sm-2" type="password" name="userpw" placeholder="Password" aria-label="Password">
          <button class="btn btn-outline-success my-1 mr-sm-2" type="submit">Sign in</button>
          <button class="btn btn-outline-primary my-1 my-sm-0" type="button" onclick="window.location='view/signup.html'">Sign up</button>
<?php
  }else{
?>
        <form class="form-inline my-1 my-lg-0" method="POST" action="services/logout.php">
        <button class="btn btn-outline-success my-1 mr-sm-5" type="submit">Sign out</button>
<?php
  }
?>
        </form>
      </div>
    </nav>

<?php
include "dao/db_conn.php";

$page_size = 10;

$page_list_size = 10;
$pno = $_GET[pno];

if (!$pno || $pno < 0)  $pno = 0;

$query_select = "SELECT no, title, name, wdate FROM board ORDER BY no DESC LIMIT $pno, $page_size";
$result = mysql_query($query_select, $conn);

$result_count=mysql_query("SELECT count(*) FROM board",$conn);
$result_row=mysql_fetch_row($result_count);
$total_row = $result_row[0];

if ($total_row <= 0) $total_row = 0;
$total_page = ceil($total_row / $page_size);

$current_page = ceil(($pno+1)/$page_size);

mysql_close($conn);
?>

    <main role="main">

      <div class="container">
        <br>
        <br>
        <br>
        <table class="table">
          <thead class="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Title</th>
              <th scope="col">User</th>
              <th scope="col">Date</th>
              <th scope="col">c_no</th>
            </tr>
          </thead>
          <tbody>
<?php
  $number = 0;
  while($row = mysql_fetch_array($result)){
    $number++;
?>
            <tr>
              <th scope="row"><?=$number?></th>
              <td><a href="view/read.php?no=<?=$row[no]?>&pno=<?=$pno?>">
		          <?=strip_tags($row[title], '<b><i>');?></a>
	            </td>
              <td><?=$row[name]?></td>
              <td><?=$row[wdate]?></td>
              <td><?=$row[no]?></td>
            </tr>
<?php
}
mysql_close($conn);
?>
          </tbody>
        </table>
        <tfoot>
        <nav aria-label="Page navigation example">
          <ul class="pagination">

<?php
$start_page = floor(($current_page - 1) / $page_list_size) * $page_list_size + 1;
$end_page = $start_page + $page_list_size - 1;

if ($total_page < $end_page) $end_page = $total_page;

if ($start_page >= $page_list_size) {
  $prev_list = ($start_page - 2)*$page_size;

  echo "<li class=\"page-item\"><a class=\"page-link\" href=\"$PHP_SELF?pno=$prev_list\">Previous</a></li>";
}


for ($i=$start_page; $i <= $end_page; $i++) {
	$page= ($i-1) * $page_size;
	if ($pno!=$page){ 
    echo "<li class=\"page-item\"><a class=\"page-link\" href=\"$PHP_SELF?pno=$page\">";
	}else{
    echo "<li class=\"page-item active\">";
    echo "<a class=\"page-link\" href=\"$PHP_SELF?pno=$page\">";
  }

	echo "$i"; 
	
	if ($pno!=$page){
		echo "</a></li>";
	}else{
    echo "<span class=\"sr-only\">(current)";
    echo "</span></a></li>";
  }
}

if($total_page > $end_page)
{
  $next_list = $end_page * $page_size;
  echo "<li class=\"page-item\"><a class=\"page-link\" href=\"$PHP_SELF?pno=$next_list\">Next</a></li>";
  
}
?>             
          </ul>
        </nav>



<?php
  if(isset( $_SESSION[is_login] ) or $_SESSION[is_login]===1){
?>        
        <button class="btn btn-outline-dark my-1 mr-sm-5" type="button" onclick="window.location='view/write.php'">Write</button>
<?php
  }
?>
        </tfoot>
      </div> <!-- /container -->

    </main>



    <footer class="container">
      <p>&copy; 2018</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="/bootstrap/site/docs/4.1/assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="/bootstrap/site/docs/4.1/assets/js/vendor/popper.min.js"></script>
    <script src="/bootstrap/dist/js/bootstrap.min.js"></script>
  </body>
</html>
