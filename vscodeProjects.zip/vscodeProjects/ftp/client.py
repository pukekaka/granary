import socket
import getpass
import sys

delim = ':::'
cmd_prefix = ''

def parse_recv(data):
    
    data_arr = data.split(delim)
    
    if len(data_arr) == 2:
        response = data_arr[0]
        data = data_arr[1]

        # welcome string
        if response == '220':
            cmd_prefix = 'USER' + delim
            recv_data = data
            return cmd_prefix, recv_data

        # logout
        elif response == '221':
            cmd_prefix = 'logout'
            recv_data = ''
            return cmd_prefix, recv_data

        # password required
        elif response == '331':
            cmd_prefix = 'PASS' + delim
            recv_data = data
            return cmd_prefix, recv_data

        # retry userid
        elif response == '332':
            cmd_prefix = 'USER' + delim
            recv_data = data
            return cmd_prefix, recv_data
        
        # retry password
        elif response == '530':
            cmd_prefix = 'PASS' + delim
            recv_data = data
            return cmd_prefix, recv_data
        
        elif response == '230' or '200':
            cmd_prefix = 'CMD' + delim
            recv_data = data
            return cmd_prefix, recv_data


def make_cmd(cmd_prefix, user_cmd):
    return cmd_prefix + user_cmd


def file_put_cmd():

    return ''

def file_get_cmd(cmd_prefix, user_cmd):
    
    return cmd_prefix + user_cmd

ip_address = '0.0.0.0'
port = 2008
data_buffer = 1024

local_hostname = socket.gethostname()
ip_address = socket.gethostbyname(local_hostname)

server_address = (ip_address, port)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
s.connect(server_address)

while True:

    data = s.recv(data_buffer)

    if data :
        cmd_prefix, recv_data = parse_recv(data)
        print recv_data,
        
        if cmd_prefix.startswith('logout'):
            print 'good bye'
            s.close() 
            sys.exit(1)

        elif cmd_prefix.startswith('PASS'):
            user_cmd = getpass.getpass('').strip().encode('utf-8')

        else:
            user_cmd = raw_input()
        
        if user_cmd.startswith('put'):
            cmd = file_put_cmd()

        elif user_cmd.startswith('get'):
            cmd = file_get_cmd(cmd_prefix, user_cmd)

        else:
            cmd = make_cmd(cmd_prefix, user_cmd)
        
        s.send(cmd)

        