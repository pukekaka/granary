import socket
import sys
import os
import getpass
import random
import hashlib
import binascii
import datetime

userenv_file = 'server/user_env' # user_id:pw_hash:salt
user_folder = 'server/user'
delim = ':::'
user_id = ''
global current_dirname
global current_dir
current_dirname = ''
current_dir = ''
data_buffer = 1024
file_path_list = []

def server_init():
    # check folders & files
    try:
        if not os.path.isdir(user_folder):
            os.makedirs(user_folder)
            if not os.path.isfile(userenv_file):
                f = open(userenv_file, 'w')
                # f.write('')
                f.close()
        # print 'ftp init pass'        
        return True
    except:
        print 'ftp init failed'
        return False


def home_init(user_id, passwd):
    try:
        with open(userenv_file, 'a') as f:
            salt = str(random.randrange(1, 10000))
            passwd = str(passwd)
            salt.strip().encode('utf-8')
            passwd.strip().encode('utf-8')
            sha256 = hashlib.pbkdf2_hmac('sha256', bytes(passwd), bytes(salt), 100000)
            passwd_hash = binascii.hexlify(sha256)

            home_folder = os.path.join(user_folder, user_id)

            if not os.path.isdir(home_folder):
                os.makedirs(home_folder)

            line = "".join([user_id, ':', passwd_hash, ':', salt, ':', '\n'])
            f.write(line)
            
            return True
    except:
        return False


def adduser(user_id):
    with open(userenv_file, 'r') as f:
        lines = f.readlines()
        for line in lines:
            user = line.split(':')
            uid = user[0]
            if uid == user_id:
                print 'already exists user id'
                sys.exit(1)

    print '## set your password ('+ user_id+ ') ##' 

    passwd = getpass.getpass('Passwd:').strip().encode('utf-8')
    verify = getpass.getpass('Verify:').strip().encode('utf-8')

    if passwd == verify:
        if home_init(user_id, passwd):
            print 'success to add a new user, ' + user_id
        else:
            print 'fail to add a new user,' + user_id
    else:
        print 'need to eqaul passwd, verify'


def make_path(user_id, path):
    home_folder = os.path.join(user_folder, user_id)

    path_arr = path.split('/')

    temp_dir = current_dir
    temp_dir_arr = current_dir.split('/')

    for path_sep in path_arr:
        if path_sep == '~':
            temp_dir = home_folder

        elif temp_dir != home_folder and path_sep == '..':
            temp_dir_arr = temp_dir_arr[:-1]
            temp_dir = '/'.join(temp_dir_arr)
        
        elif temp_dir == home_folder and path_sep == '..':
            temp_dir = home_folder

        elif path_sep == '.':
            temp_dir = temp_dir

        else:
            temp_dir = os.path.join(temp_dir, path_sep)

    target_dir = temp_dir

    # print 'current_dir', current_dir
    # print 'target_dir', target_dir

    return target_dir


def make_shell():
    shell = '\n'+user_id+'@ftp/'+current_dirname+'>> '

    return shell


def exe_cmd1(data, cmd):

    recv_data = data

    if cmd == 'USER':
        try:
            existsID = False
            with open(userenv_file, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    user = line.split(':')
                    uid = user[0]
                    if uid == recv_data:
                        existsID = True
                        global user_id
                        user_id = uid
            if existsID:
                result = '331:::# password:'
                return result
            else:
                result = '332:::Not match your ID\n# user:'
                return result
        except:
            result = '000:::server error!!!'
            return result
    
    if cmd == 'PASS':
        rightPASSWD = False
        try:
            with open(userenv_file, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    user = line.split(':')
                    uid = user[0]
                    passwd_hash = user[1]
                    salt = user[2]
                    passwd = recv_data
                    if uid == user_id:
                        salt.strip('\n').encode('utf-8')
                        passwd.strip().encode('utf-8')
                        sha256 = hashlib.pbkdf2_hmac('sha256', bytes(passwd), bytes(salt), 100000)
                        calculate_hash = binascii.hexlify(sha256)
                        print calculate_hash
                        if calculate_hash == passwd_hash:
                            rightPASSWD = True
            if rightPASSWD:
                global current_dirname
                global current_dir 
                current_dir = os.path.join(user_folder, user_id)
                current_dirname = user_id

                result = '230:::Logged In\n'+ make_shell()
                return result
            else:
                result = '530:::Logged Failed\n# password:'
                return result
        except:
            result = '000:::server error!!'+ make_shell()
            return result

    if cmd == 'logout':
        result = '221:::logout'

        return result


def exe_cmd2(user_id, cmd, path):
    path = make_path(user_id, path)

    if cmd == 'ls':
        try:
            result_list = []
            
            all_list = os.listdir(path)

            for item in all_list:
                file_path = os.path.join(path, item)
                
                file_name = item
                file_size = str(os.path.getsize(file_path))
                file_cdate = str(datetime.datetime.fromtimestamp(os.path.getctime(file_path)))

                if os.path.isfile(file_path):
                    file_type = 'f'
                
                elif os.path.isdir(file_path):
                    file_type = 'd'

                line = " ".join([file_type, file_size, file_cdate, file_name, '\n'])
                result_list.append(line)
            
            result = '200:::'+"".join(result_list)+make_shell()

            print result

            return result
        except:
            result = '200:::No such file or directory'+make_shell()
            # print result
            return result

    elif cmd == 'mkdir':
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
                result = '200:::success mkdir'+make_shell()
                # print result
                return result
            else:
                result = '200:::already exists folder'+make_shell()
                # print result
                return result
        except:
            result = '200:::failed mkdir'+make_shell()
            # print result
            return result
    
    elif cmd == 'rmdir':
        try:
            if os.path.isdir(path):
                os.rmdir(path)
                result = '200:::success rmdir'+make_shell()
                # print result
                return result
            else:
                result = '200:::No such file or directory'+make_shell()
                # print result
                return result
        except:
            result = '200:::Folder is not empty'+make_shell()
            # print result
            return result
    
    elif cmd == 'rm':
        try:
            if os.path.isfile(path):
                os.remove(path)
                result = '200:::success remove file' + make_shell()
                return result
            else:
                result = '200:::No such file' + make_shell()
                return result
        except:
            result = '200:::failed remove file' + make_shell()
            return result

    elif cmd == 'cd':
        global current_dir
        global current_dirname

        if os.path.isdir(path):
            current_dir = path
            current_dirname = os.path.basename(current_dir)
            result = '200:::'+make_shell()

            return result
        else:
            result = '200:::No such directory'+make_shell()
            return result


def exe_cmd3(user_id, cmd, path1, path2):
    
    if cmd == 'put':
        return 
    

    elif cmd == 'get':
        filelist = path1.split(',')
        global file_path_list
        for filename in filelist:
            file_path_list.append(make_path(user_id, filename))
        
        # return file_path_list
        return '200:::get'+make_shell()

    return '000:::error'


def parse_cmd(data):
    global user_id

    data_arr = data.split()

    # ls, logout 
    if len(data_arr) == 1:
        cmd = data_arr[0]
        if cmd == 'ls':
            result = exe_cmd2(user_id, cmd, '.')
            return result
        elif cmd == 'logout':
            result = exe_cmd1(user_id, cmd)
            return result
        else:
            result = '000:::error'
            return result

    # ls, mkdir, rmdir, cd, rm, put, get
    elif len(data_arr) == 2:
        
            cmd = data_arr[0].strip()
            path = data_arr[1].strip()
            if cmd in ['ls', 'mkdir', 'rmdir', 'cd', 'rm']:
                result = exe_cmd2(user_id, cmd, path)
                return result
            else:
                result = '000:::error'
                return result 

    # put, get 
    elif len(data_arr) == 3:
        cmd = data_arr[0]
        path1 = data_arr[1]
        path2 = data_arr[2]

        result = exe_cmd3(user_id, cmd, path1, path2)
        return result

    else:
        result = '000:::error'
        return result


def parse_recv(data):
    data_arr = data.split(delim)

    if len(data_arr) == 2:
        request = data_arr[0]
        data = data_arr[1]

        # USER
        if request == 'USER':
            recv_data = data
            resp_data = exe_cmd1(recv_data, 'USER')

            return resp_data

        # password required
        if request == 'PASS':
            recv_data = data
            resp_data = exe_cmd1(recv_data, 'PASS')
            
            return resp_data
        
        if request == 'CMD':
            recv_data = data
            resp_data = parse_cmd(data)

            return resp_data


def ftp():

    ip_address = '0.0.0.0'
    port = 2008
    
    local_hostname = socket.gethostname()
    ip_address = socket.gethostbyname(local_hostname)
    server_address = (ip_address, port)

    welcome_str = '220:::Hello, welcome to KSW FTP Service!!\n# user:'
    
    # print ip_address, port

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(server_address)
    s.listen(1)

    print ('KSW FTP Service Started...')

    connection, client_address = s.accept()
    connection.send(welcome_str)
    
    # try:
    while True:
        
        data = connection.recv(data_buffer)
        if data:
            print data
            resp_data = parse_recv(data)
            if 'logout' in resp_data :
                break
            
            # elif 'get' in resp_data :        
                

            # print resp_data
            else:
                connection.send(resp_data)

    connection.send(resp_data)
    connection.close()
    print ('disconnected client!!')
    

def main():

    # args = sys.argv[2:] # python ftp_server.py
    # if not args:
    #     print 'usage: [--adduser user_id] [--ftp]'
    #     sys.exit(1)

    # if args[0] == '--adduser':
    #     user_id = args[1]
    #     del args[0:2]

    # if args[0] ==  '--deluser':
    #     user_id = args[1]
    #     del args[0:2]

    # if len(args) == 0:
    #     print "error: must specify one or more dirs"
    #     sys.exit(1)

    # server_init()
    # adduser('kang')
        # adduser('john')
    ftp()


if __name__ == '__main__':
    main()