T = ''
line_list = []

# Big = 'C-large-practice.in'
Small = 'C-small-practice.in'

odd = False

with open (Small, 'rb') as f:
    lines = f.readlines()
    for idx, line in enumerate(lines):
        if idx == 0:
            T = line.strip()
        else:
            row = line.split()
            A = int(row[0])
            B = int(row[1])

            if (B - A) % 2 == 1:
                odd = True
            result = 0
            for n in range(A, B+1):
                n_str = str(n)
                n_cnt = len(n_str)

                for cnt in range(0, n_cnt-1):
                    loc = cnt +1
                    front_slice = n_cnt - loc
                    back_slice = loc
                    m = n_str[-back_slice:] + n_str[:front_slice]
                    
                    if n < int(m) and int(m) <=B:
                        result = result + 1
                        
            if odd and result > 0: 
                result = result -1
            print 'Case #'+str(idx)+': '+ str(result)