
N = ''
line_list = []

Big = 'B-large-practice.in'
Small = 'B-small-practice.in'

with open (Big, 'rb') as f:
    lines = f.readlines()
    for idx, line in enumerate(lines):
        if idx == 0:
            N = line.strip()
        else:
            row = line.split()
            row.reverse()
            
            print 'Case #'+str(idx)+': '+" ".join(row)